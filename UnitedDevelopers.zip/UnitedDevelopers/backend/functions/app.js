const express = require("express");
const serverless = require("serverless-http");
const app = express();
const router = express.Router();
require("dotenv").config();
const mongoose = require("mongoose");
const basicAuth = require("basic-auth");
const cors = require("cors");
app.use(express.json());
app.use(cors());

const USER_USER = "user";
const USER_PASSWORD = "password";

const ADMIN_USER = "admin";
const ADMIN_PASSWORD = "secret";

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// User Schema
const UserSchema = new mongoose.Schema({
  password: { type: String, required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  role: { type: String, required: true, enum: ["admin", "user"] }, // Add role
});

const TaskSchema = new mongoose.Schema({
  problemDescription: String,
  status: String,
  priority: String,
  createdDate: String,
  updatedDate: String,
  duration: String,
  email: String,
});

const TreasurySchema = new mongoose.Schema({
  name: String,
  task: String,
  date: String,
  notes: String,
  amount: Number,
  type: String,
  email: String,
  updatedDate: String,
});

// MOM Schema & Model
const
  momSchema = new mongoose.Schema({
    text: String,
    email: String,
    updatedDate: String,
  });

const enquirySchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  message: String,
  status: { type: String, default: 'Submitted' },
  date: { type: Date, default: Date.now }
});

const Enquiry = mongoose.model("Enquiry", enquirySchema);

const MOM = mongoose.model("momdata", momSchema);

const Task = mongoose.model("expensetypes", TaskSchema);
const Treasury = mongoose.model("treasuryentries", TreasurySchema);
const User = mongoose.model("adminusers", UserSchema);

// Basic Authentication Middleware for POST, PUT, DELETE
const authMiddlewareAdmin = (req, res, next) => {
  if (["POST", "PUT", "DELETE"].includes(req.method)) {
    const user = basicAuth(req);
    if (!user || user.name !== ADMIN_USER || user.pass !== ADMIN_PASSWORD) {
      res.set("WWW-Authenticate", 'Basic realm="401"');
      return res.status(401).json({ message: "Unauthorized" });
    }
  }
  next();
};

// Basic Authentication Middleware for POST, PUT, DELETE
const authMiddlewareUser = (req, res, next) => {
  if (["POST"].includes(req.method)) {
    const user = basicAuth(req);
    if (!user || user.name !== USER_USER || user.pass !== USER_PASSWORD) {
      res.set("WWW-Authenticate", 'Basic realm="401"');
      return res.status(401).json({ message: "Unauthorized" });
    }
  }
  next();
};

// Register API
router.post("/register", authMiddlewareUser, async (req, res) => {
  const { password, name, email, role } = req.body;
  if (!/^.{10,}$/.test(name)) return res.status(400).json({ message: "Please provide full name, minimum 10 characters" });
  if (!/^.{8,}$/.test(password)) return res.status(400).json({ message: "Password should consists of minimum 8 characters" });

  try {
    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ message: "User already registered" });

    const newUser = new User({ password, name, email, role });
    await newUser.save();
    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

// Login API (Dummy Captcha Validation)
router.post("/login", authMiddlewareUser, async (req, res) => {
  const { password, email } = req.body;
  // if (!/^.{8,}$/.test(aadhar)) return res.status(400).json({ message: "Invalid Aadhar Number" });

  const user = await User.findOne({ password, email });
  if (!user) return res.status(400).json({ message: "User not found" });

  res.status(200).json({ message: "Login successful", id: user._id, email: user.email });
});

router.post("/enquiry", authMiddlewareUser, async (req, res) => {
  try {
    const newEnquiry = new Enquiry(req.body);
    await newEnquiry.save();
    res.json({ success: true, message: "Enquiry submitted successfully" });
  } catch (error) {
    res.status(500).json({ message: "There was an error submitting your enquiry", error: error });
  }
});

router.use(authMiddlewareAdmin);

router.get("/user/role/check", async (req, res) => {
  try {
    const { _id } = req.query;
    const user = await User.findOne({ _id });
    res.json({ isAdmin: !user ? false : (user.role === "admin_user"), exists: !user ? false : true });
  } catch (err) {
    res.status(500).json({ isAdmin: false, exists: false });
  }
});

router.get("/users/count", async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    res.status(200).json({ count: userCount });
  } catch (err) {
    res.status(500).json({ message: "Error fetching user count", error: err });
  }
});

router.get("/users", async (req, res) => {
  try {
    const users = await User.find({}, { name: 1, email: 1, _id: 0 }); // Fetch Users from MongoDB
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: "Error fetching users data", error: err });
  }
});

// Routes
router.post("/tasks", async (req, res) => {
  try {
    const task = new Task(req.body);
    const today = new Date().toISOString().split("T")[0];;
    task.createdDate = today;
    task.duration = 0;
    // Calculate duration in days
    if (!task.updatedDate) {
      const created = new Date(task.createdDate);
      const updated = new Date(task.updatedDate);
      const diffTime = updated - created; // difference in milliseconds
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // convert to days
      task.duration = diffDays;
    }
    await task.save();
    res.status(200).json({ message: "New task created successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update Task
router.put("/tasks/:id", async (req, res) => {
  try {
    const { task, email } = req.body;
    task.email = email;
    task.duration = 0;
    // Calculate duration in days
    if (!task.updatedDate) {
      const created = new Date(task.createdDate);
      const updated = new Date(task.updatedDate);
      const diffTime = updated - created; // difference in milliseconds
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // convert to days
      task.duration = diffDays;
    }
    await Task.findByIdAndUpdate(req.params.id, task);
    res.json({ message: "Task updated successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/tasks", async (req, res) => {
  try {
    const tasks = await Task.find().sort({ updatedDate: -1 });
    res.send(tasks);
  } catch (err) {
    res.status(500).json({ message: "Error fetching tasks data", error: err });
  }
});

router.post("/treasury", async (req, res) => {
  try {
    const entry = new Treasury(req.body);
    await entry.save();
    res.status(200).json({ message: "New account entry created successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update Task
router.put("/treasury/:id", async (req, res) => {
  try {
    const treasury = req.body;
    treasury.updatedDate = new Date().toISOString().split("T")[0];
    await Treasury.findByIdAndUpdate(req.params.id, treasury);
    res.status(200).json({ message: "Account entry updated successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/treasury", async (req, res) => {
  try {
    const debits = await Treasury.find({ type: "Debit" }).sort({ date: -1 });
    const credits = await Treasury.find({ type: "Credit" }).sort({ date: -1 });
    res.status(200).json({ debits, credits });
  } catch (err) {
    res.status(500).json({ message: "Error fetching treasury data", error: err });
  }
});

router.post("/mom", async (req, res) => {
  const { email, text } = req.body;
  try {

    let mom = new MOM({ text, email });
    await mom.save();
    res.status(201).json({ message: "MOM created successfully" });

  } catch (err) {
    res.status(500).json({ message: "Error saving MOM entry." });
  }
});

// GET endpoint to fetch MOM
router.get("/mom", async (req, res) => {
  try {
    const mom = await MOM.findOne().sort({ _id: -1 }).limit(1); // Get the latest MOM
    res.status(200).json(mom);
  } catch (err) {
    res.status(500).json({ message: "Error fetching MOM", error: err });
  }
});

router.get("/leads", async (req, res) => {
  try {
    const leads = await Enquiry.find().sort({ updatedDate: -1 });
    res.send(leads);
  } catch (err) {
    res.status(500).json({ message: "Error fetching leads data", error: err });
  }
});

router.put("/leads/:id", authMiddlewareAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    await Enquiry.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json({ message: "Lead status updated successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.use("/.netlify/functions/app", router);
module.exports.handler = serverless(app);