import React, { useState } from "react";
import "./App.css";
import { FaPhoneAlt, FaEnvelope, FaMapMarkerAlt, FaTimes } from "react-icons/fa";
import axios from "axios";
import { USER_USER, USER_PASSWORD, BASE_URI } from "./util";

import Elevation from "./assets/elevation.jpg";
import FloorPlan from "./assets/floorplan.jpg";
import BHK3 from "./assets/3bhk.jpg";
import BHK2 from "./assets/2bhk.jpg";
import Parking from "./assets/parking.jpg";
import LocationQR from "./assets/locationqr.jpg";
import logo from "./assets/logo.jpg";

const carouselImages = [
    { src: FloorPlan, caption: "Floor Plan", link: "#floorplan" },
    { src: BHK3, caption: "3BHK Flat Plan", link: "#3bhk" },
    { src: BHK2, caption: "2BHK Flat Plan", link: "#2bhk" },
    { src: Parking, caption: "Parking Plan", link: "#parking" },
];

const Home = () => {
    const [current, setCurrent] = useState(0);
    const [zoomImage, setZoomImage] = useState(null); // For zoom modal
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phone: "",
        message: "",
    });
    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e) =>
        setFormData({ ...formData, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post(BASE_URI + "/enquiry", formData, {
            auth: {
                username: USER_USER,
                password: USER_PASSWORD,
            }
        }).then((response) => {
            alert(response.data.message);
            setSubmitted(true);
            setFormData({ name: "", email: "", phone: "", message: "" });

        });
    };

    const handleImageClick = (src) => setZoomImage(src);
    const closeZoom = () => setZoomImage(null);

    return (
        <div className="home-container">
            {/* Header */}
            <header className="header">
                <div className="header-left">
                    <h1 className="project-name">UNITED AVAASA</h1>
                    <h2 className="project-tagline">Welcome to an Abundant Life at <i>United Avaasa</i></h2>
                    <p className="project-desc">
                        Premium 3BHK & 2BHK flats in the heart of Hyderabad with modern amenities and secure living.
                    </p>
                </div>
                <div className="header-right">
                    <img src={logo} alt="United Developers" className="header-image" />
                </div>
            </header>

            {/* Main Section */}
            <div className="main-section">
                {/* Elevation */}
                <div className="elevation-container">
                    <img
                        src={Elevation}
                        alt="Elevation"
                        className="elevation-image"
                        onClick={() => handleImageClick(Elevation)}
                    />
                </div>

                {/* Carousel */}
                <div className="carousel-container">
                    {/* Links */}
                    <div className="carousel-links">
                        {carouselImages.map((img, idx) => (
                            <button
                                key={idx}
                                className={`carousel-link ${current === idx ? "active" : ""}`}
                                onClick={() => setCurrent(idx)}
                            >
                                {img.caption}
                            </button>
                        ))}
                    </div>

                    <img
                        src={carouselImages[current].src}
                        alt={carouselImages[current].caption}
                        className="carousel-image"
                        onClick={() => handleImageClick(carouselImages[current].src)}
                    />
                </div>
            </div>

            {/* Project Info Section */}
            <div className="project-info">
                <div className="project-card">
                    <h3>Project Details</h3>
                    <ul>
                        <li>Spacious 3BHK & 2BHK Flats</li>
                        <li>HMDA Approved</li>
                        <li>East & West Facing Flats</li>
                        <li>3BHK - 1450 sft</li>
                        <li>2BHK - 1125 sft</li>
                        <li>5 Floors & 10 Flats</li>
                    </ul>
                </div>

                <div className="project-card">
                    <h3>Project Facilities</h3>
                    <ul>
                        <li>100% Vastu</li>
                        <li>Ample parking for 2 & 4 wheelers</li>
                        <li>24/7 Power backup</li>
                        <li>CCTV surveillance across premises</li>
                        <li>Soundproof windows / UPVC sliding doors</li>
                        <li>Branded Electrical fittings & concealed wiring</li>
                        <li>Premium flooring (vitrified tiles)</li>
                        <li>Kitchen with granite platform & cement shelves</li>
                        <li>Two deep borewells (1400 each) for reliable water supply</li>
                    </ul>
                </div>

                <div className="project-card">
                    <h3>Project Connectivity</h3>
                    <ul>
                        <li>6 KM to ORR Exit 4</li>
                        <li>6 KM to Miyapur X road</li>
                        <li>1 KM to Panchatatva Park</li>
                        <li>40 Mins to Mindspace IT Park</li>
                    </ul>
                </div>
            </div>

            {/* Contact & Enquiry */}
            <div className="bottom-section">
                <div className="contact-container">
                    <h2>Contact Us</h2>
                    <p><FaMapMarkerAlt className="icon" /> Opposite Viru International Office, Near Hanuman Temple, Ameenpur, Hyderabad</p>
                    <p><FaPhoneAlt className="icon" /> +91 9666784555</p>
                    <p><FaEnvelope className="icon" /> uniteddevelopers.hyd@gmail.com</p>
                    <div className="qr-section">
                        <p>📷 Scan the QR code for Google Maps location:</p>
                        <img
                            src={LocationQR}
                            alt="Location QR Code"
                            className="qr-image"
                        />
                        <br />
                        <a
                            href="https://maps.app.goo.gl/X1mzN1AcG2XU4Xn79"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="map-link"
                        >
                            View on Google Maps
                        </a>
                    </div>
                </div>

                <div className="enquiry-container">
                    <h2>Enquire (OR) Book Now</h2>
                    <form className="enquiry-form" onSubmit={handleSubmit}>
                        <input
                            type="text"
                            name="name"
                            placeholder="Full Name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                        <input
                            type="email"
                            name="email"
                            placeholder="Email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                        <input
                            type="text"
                            name="phone"
                            placeholder="Phone"
                            value={formData.phone}
                            onChange={handleChange}
                            required
                        />
                        <textarea
                            name="message"
                            placeholder="Message"
                            value={formData.message}
                            onChange={handleChange}
                            rows="3"
                            required
                        />
                        <button type="submit">Submit</button>
                        {submitted && <p className="success-msg">Thank you! We will contact you soon.</p>}
                    </form>
                </div>
            </div>

            {/* Zoom Modal */}
            {zoomImage && (
                <div className="zoom-modal" onClick={closeZoom}>
                    <span className="zoom-close"><FaTimes /></span>
                    <img src={zoomImage} alt="Zoom" className="zoom-image" />
                </div>
            )}
        </div>
    );
};

export default Home;
