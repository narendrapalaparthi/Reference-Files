package vault.gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VaultSecretManagerFX extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Title
        Label title = new Label("OCI Vault Secret Manager");
        title.setStyle("-fx-font-size: 20; -fx-font-weight: bold; -fx-text-fill: #0071CE;");

        // Form fields
        ComboBox<String> actionCombo = new ComboBox<>();
        actionCombo.getItems().addAll("Fetch", "Update");
        ComboBox<String> vaultSecretCombo = new ComboBox<>();
        TextField descriptionField = new TextField();
        TextField newValueField = new TextField();

        Button executeBtn = new Button("Execute");
        Button resetBtn = new Button("Reset");

        TextArea responseArea = new TextArea();
        Button clearBtn = new Button("Clear");
        Button copyBtn = new Button("Copy");

        // Layout
        GridPane form = new GridPane();
        form.setVgap(10);
        form.setHgap(10);
        form.add(new Label("Action:"), 0, 0);
        form.add(actionCombo, 1, 0);
        form.add(new Label("Select Vault Secret:"), 0, 1);
        form.add(vaultSecretCombo, 1, 1);
        form.add(new Label("Description:"), 0, 2);
        form.add(descriptionField, 1, 2);
        form.add(new Label("New Value:"), 0, 3);
        form.add(newValueField, 1, 3);
        form.add(executeBtn, 0, 4);
        form.add(resetBtn, 1, 4);

        VBox root = new VBox(15, title, form, responseArea, new HBox(10, clearBtn, copyBtn));
        root.setStyle("-fx-padding: 18px; -fx-background-color: white;");
        Scene scene = new Scene(root, 520, 480);

        primaryStage.setTitle("OCI Vault — Secret Fetch / Update");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}