const express = require("express");
const serverless = require("serverless-http");
const app = express();
require("dotenv").config();
const mongoose = require("mongoose");
const basicAuth = require("basic-auth");
const cors = require("cors");
app.use(express.json());
app.use(cors());

const USER_USER = "user";
const USER_PASSWORD = "password";

const ADMIN_USER = "admin";
const ADMIN_PASSWORD = "secret";

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// User Schema
const UserSchema = new mongoose.Schema({
  password: { type: String, required: true },
  name: { type: String, required: true },
  mobile: { type: String, required: true, unique: true },
  role: { type: String, required: true, enum: ["admin", "user"] }, // Add role
});

const TaskSchema = new mongoose.Schema({
  problemDescription: String,
  status: String,
  priority: String,
  temporarySolution: String,
  permanentSolution: String,
  owners: String,
  createdDate: String,
  updatedDate: String,
  comments: String,
  mobile: String,
});

const TreasurySchema = new mongoose.Schema({
  name: String,
  task: String,
  date: String,
  notes: String,
  amount: Number,
  type: String,
  mobile: String,
});

// MOM Schema & Model
const momSchema = new mongoose.Schema({
  text: String,
  mobile: String,
});

const MOM = mongoose.model("MOM", momSchema);

const Task = mongoose.model("Task", TaskSchema);
const Treasury = mongoose.model("Treasury", TreasurySchema);
const User = mongoose.model("User", UserSchema);

// Basic Authentication Middleware for POST, PUT, DELETE
const authMiddlewareAdmin = (req, res, next) => {
  if (["POST", "PUT", "DELETE"].includes(req.method)) {
    const user = basicAuth(req);
    if (!user || user.name !== ADMIN_USER || user.pass !== ADMIN_PASSWORD) {
      res.set("WWW-Authenticate", 'Basic realm="401"');
      return res.status(401).json({ message: "Unauthorized" });
    }
  }
  next();
};

// Basic Authentication Middleware for POST, PUT, DELETE
const authMiddlewareUser = (req, res, next) => {
  if (["POST"].includes(req.method)) {
    const user = basicAuth(req);
    if (!user || user.name !== USER_USER || user.pass !== USER_PASSWORD) {
      res.set("WWW-Authenticate", 'Basic realm="401"');
      return res.status(401).json({ message: "Unauthorized" });
    }
  }
  next();
};

// Register API
app.post("/register", authMiddlewareUser, async (req, res) => {
  const { password, name, mobile, role } = req.body;
  if (!/^.{10,}$/.test(name)) return res.status(400).json({ message: "Please provide full name, minimum 10 characters" });
  if (!/^.{8,}$/.test(password)) return res.status(400).json({ message: "Password should consists of minimum 8 characters" });

  try {
    const userExists = await User.findOne({ mobile });
    if (userExists) return res.status(400).json({ message: "User already registered" });

    const newUser = new User({ password, name, mobile, role });
    await newUser.save();
    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

// Login API (Dummy Captcha Validation)
app.post("/login", authMiddlewareUser, async (req, res) => {
  const { password, mobile } = req.body;
  // if (!/^.{8,}$/.test(aadhar)) return res.status(400).json({ message: "Invalid Aadhar Number" });

  const user = await User.findOne({ password, mobile });
  if (!user) return res.status(400).json({ message: "User not found" });

  res.status(200).json({ message: "Login successful", id: user._id , mobile: user.mobile});
});

app.use(authMiddlewareAdmin);

app.get("/user/role/check", async (req, res) => {
  try {
    const { _id } = req.query;
    const user = await User.findOne({ _id });
    res.json({ isAdmin: !user ? false : (user.role === "admin_user"), exists: !user ? false : true });
  } catch (err) {
    res.status(500).json({ isAdmin: false, exists: false });
  }
});

app.get("/users/count", async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    res.status(200).json({ count: userCount });
  } catch (err) {
    res.status(500).json({ message: "Error fetching user count", error: err });
  }
});

app.get("/users", async (req, res) => {
  try {
    const users = await User.find({}, { name: 1, mobile: 1, _id: 0 }); // Fetch Users from MongoDB
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: "Error fetching users data", error: err });
  }
});

// Routes
app.post("/tasks", async (req, res) => {
  const task = new Task(req.body);
  const today = new Date().toISOString().split("T")[0];;
  task.createdDate = today;
  task.updatedDate = today;
  await task.save();
  res.send(task);
});

// Update Task
app.put("/tasks/:id", async (req, res) => {
  try {
    const { task, mobile } = req.body;
    task.updatedDate = new Date().toISOString().split("T")[0];
    task.mobile = mobile;
    console.log(task)
    await Task.findByIdAndUpdate(req.params.id, task);
    res.json({ message: "Task updated" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get("/tasks", async (req, res) => {
  try {
    const tasks = await Task.find().sort({ updatedAt: -1 });
    res.send(tasks);
  } catch (err) {
    res.status(500).json({ message: "Error fetching tasks data", error: err });
  }
});

app.post("/treasury", async (req, res) => {
  try {
    const entry = new Treasury(req.body);
    await entry.save();
    res.status(200).json({ message: "New account entry created successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get("/treasury", async (req, res) => {
  try {
    const debits = await Treasury.find({ type: "Debit" }).sort({ updatedAt: -1 });
    const credits = await Treasury.find({ type: "Credit" }).sort({ updatedAt: -1 });
    res.status(200).json({ debits, credits });
  } catch (err) {
    res.status(500).json({ message: "Error fetching treasury data", error: err });
  }
});

app.post("/mom", async (req, res) => {
  const { mobile, text } = req.body;

  try {
    let mom = await MOM.findOne();  // Check if a MOM entry already exists
    if (mom) {
      // If entry exists, update it
      mom.text = text;
      mom.mobile = mobile;
      await mom.save();
      res.status(200).json({ message: "MOM updated successfully" });
    } else {
      // If no entry exists, create a new one
      mom = new MOM({ text, mobile });
      await mom.save();
      res.status(201).json({ message: "MOM created successfully" });
    }
  } catch (err) {
    res.status(500).json({ message: "Error saving MOM entry." });
  }
});

// GET endpoint to fetch MOM
app.get("/mom", async (req, res) => {
  try {
    const mom = await MOM.findOne().sort({ _id: -1 }).limit(1); // Get the latest MOM
    res.status(200).json(mom);
  } catch (err) {
    res.status(500).json({ message: "Error fetching MOM", error: err });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));