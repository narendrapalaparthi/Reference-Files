//const BASE_URI = "https://bvpalemapi.netlify.app/.netlify/functions/app";
const BASE_URI = "http://localhost:5000";
const USERNAME = "admin";
const PASSWORD = "secret";