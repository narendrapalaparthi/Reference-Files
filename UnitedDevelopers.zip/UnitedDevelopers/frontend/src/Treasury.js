import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./App.css";
import { ADMIN_USER, ADMIN_PASSWORD, BASE_URI, checkRole, userExist, isUserAdmin } from "./util";
import Select from 'react-select';

const Treasury = () => {
    const [activeTab, setActiveTab] = useState("treasury");
    const [tasks, setTasks] = useState([]);
    const [users, setUsersArray] = useState([]);
    const [debitsNameWise, setDebitsNameWise] = useState([]);
    const [debitsTaskWise, setDebitsTaskWise] = useState([]);
    const [credits, setCredits] = useState([]);
    const [sortedUsers, setSortedUsers] = useState([]);
    const [showPopup, setShowPopup] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);
    const navigate = useNavigate();

    const [isDebitNameOpen, setIsDebitNameOpen] = useState(false);
    const [isDebitTaskOpen, setIsDebitTaskOpen] = useState(true);
    const [isCreditOpen, setIsCreditOpen] = useState(true);
    const [expandedName, setExpandedName] = useState(null);

    const [treasuryForm, setTreasuryForm] = useState({
        name: "",
        task: "",
        notes: "",
        amount: "",
        type: "",
        date: "",
        mobile: localStorage.getItem("mobile"),
    });

    const handleTreasuryChange = (e) => setTreasuryForm({ ...treasuryForm, [e.target.name]: e.target.value });

    const handleSearchSelect = (e) => {
        setSelectedOption(e.value);
        console.log("Selected User:", selectedOption);
        setTreasuryForm({ ...treasuryForm, [e.name]: e.value });
    }

    // Fetch Data
    useEffect(() => {
        checkRole();
        if (false) { }
        // navigate("/login");
        else {
            axios.get(BASE_URI + "/tasks").then((res) => setTasks(res.data));
            axios.get(BASE_URI + "/treasury").then((res) => {
                const debitsData = res.data.debits;
                const creditsData = res.data.credits;

                // Group debits by task
                const debitTaskGroupedData = debitsData.reduce((acc, entry) => {
                    if (!acc[entry.task]) {
                        acc[entry.task] = {
                            totalAmount: 0,
                            details: []
                        };
                    }
                    acc[entry.task].totalAmount += entry.amount;
                    acc[entry.task].details.push(entry);
                    return acc;
                }, {});

                // Group debits by name
                const debitNameGroupedData = debitsData.reduce((acc, entry) => {
                    if (!acc[entry.name]) {
                        acc[entry.name] = {
                            totalAmount: 0,
                            details: []
                        };
                    }
                    acc[entry.name].totalAmount += entry.amount;
                    acc[entry.name].details.push(entry);
                    return acc;
                }, {});
                const creditGroupedData = creditsData.reduce((acc, entry) => {
                    if (!acc[entry.name]) {
                        acc[entry.name] = {
                            totalAmount: 0,
                            details: []
                        };
                    }
                    acc[entry.name].totalAmount += entry.amount;
                    acc[entry.name].details.push(entry);
                    return acc;
                }, {});
                setDebitsNameWise(debitNameGroupedData);
                setDebitsTaskWise(debitTaskGroupedData)
                setCredits(creditGroupedData);
                const sortedUsers = Object.keys(creditGroupedData);
                setSortedUsers(sortedUsers);
                console.log(sortedUsers);
            });
            axios.get(BASE_URI + "/users")
                .then((response) => {
                    const userOptions = response.data.map((user) => ({
                        value: user.name,
                        label: user.name,
                        name: "name"
                    }));
                    setUsersArray(userOptions);
                })
                .catch((err) => {
                    console.error("Error fetching users:", err);
                });
        }
    }, [navigate]);

    // Add Treasury Entry
    const addTreasuryEntry = async (e) => {
        e.preventDefault();
        try {
            await axios.post(BASE_URI + "/treasury", treasuryForm, {
                auth: {
                    username: ADMIN_USER,
                    password: ADMIN_PASSWORD,
                }
            }).then((response) => {
                alert(response.data.message);
            });
            setShowPopup(false); // Close popup after submit
            setTreasuryForm({ name: "", notes: "", amount: "", type: "", date: "" });
            window.location.reload(); // Refresh to fetch new data
        } catch (err) {
            console.error("Error adding entry:", err);
        }
    };

    const launchActiveTab = (tab) => {
        setActiveTab(tab);
        navigate("/" + tab);
    }

    return (
        <div className="App">
            <div className="sidebar">
                <div >
                    {["dashboard", "treasury", "mom"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </div>
                {/* {isUserAdmin && <span>
                    {["task"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </span>} */}
            </div>

            <div className="content">
                <div className="section">
                    {/* <h2>💰 Treasury Accounts</h2> */}
                    {isUserAdmin && <button className="add-entry-btn" onClick={() => setShowPopup(true)}>➕ Add Entry</button>}
                    {/* Credit Section */}
                    <div className="treasury-section credit">
                        <h3 onClick={() => setIsCreditOpen(!isCreditOpen)} className="collapsible-header">
                            📈 Credits {isCreditOpen ? "🔽" : "▶️"}
                        </h3>
                        {isCreditOpen && (
                            <table className="styled-table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Total Amount Funded</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Object.keys(credits).length > 0 ? (
                                        sortedUsers.map(name => (
                                            <tr key={name}>
                                                <td style={{ textAlign: "center" }} onClick={() => setExpandedName(expandedName === name ? null : name)}>
                                                    {expandedName === name ? "▶️" : "🔽"}
                                                </td>
                                                <td>{name}</td>
                                                <td>₹{credits[name].totalAmount}</td>
                                                {expandedName === name &&
                                                    <div className="popup-overlay">
                                                        <div className="popup-content">
                                                            <table>
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Task</th>
                                                                        <th>Date</th>
                                                                        <th>Amount</th>
                                                                        <th>Notes</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {credits[name].details.length > 0 ? (
                                                                        (credits[name].details.map((entry, index) => (
                                                                            <tr key={entry._id}>
                                                                                <td>{entry.name}</td>
                                                                                <td>{entry.task}</td>
                                                                                <td>{entry.date}</td>
                                                                                <td>₹{entry.amount}</td>
                                                                                <td>{entry.notes}</td>
                                                                            </tr>
                                                                        ))
                                                                        )) : (
                                                                        <tr><td colSpan="3">No credit entries found.</td></tr>
                                                                    )}
                                                                </tbody>
                                                            </table>
                                                            <button type="button" className="close-btn" onClick={() => setExpandedName(expandedName === name ? null : name)}>Close</button>
                                                        </div>
                                                    </div>}
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="3">No credit entries found.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        )}
                    </div>
                    {/* Debit Section */}
                    <div className="treasury-section debit">
                        <h3 onClick={() => setIsDebitTaskOpen(!isDebitTaskOpen)} className="collapsible-header">
                            📉 Debits - Task Wise {isDebitTaskOpen ? "🔽" : "▶️"}
                        </h3>
                        {isDebitTaskOpen && (
                            <table className="styled-table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Task</th>
                                        <th>Total Amount Spent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Object.keys(debitsTaskWise).length > 0 ? (
                                        Object.keys(debitsTaskWise).map(task => (
                                            <tr key={task}>
                                                <td style={{ textAlign: "center" }} onClick={() => setExpandedName(expandedName === task ? null : task)}>
                                                    {expandedName === task ? "▶️" : "🔽"}
                                                </td>
                                                <td>{task}</td>
                                                <td>₹{debitsTaskWise[task] ?.totalAmount || 0}</td>
                                                {expandedName === task &&
                                                    <div className="popup-overlay">
                                                        <div className="popup-content">
                                                            <table >
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Task</th>
                                                                        <th>Date</th>
                                                                        <th>Amount</th>
                                                                        <th>Notes</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {debitsTaskWise[task].details.length > 0 ? (
                                                                        (debitsTaskWise[task].details.map((entry, index) => (
                                                                            <tr key={entry._id}>
                                                                                <td>{entry.name}</td>
                                                                                <td>{entry.task}</td>
                                                                                <td>{entry.date}</td>
                                                                                <td>₹{entry.amount}</td>
                                                                                <td>{entry.notes}</td>
                                                                            </tr>
                                                                        ))
                                                                        )) : (
                                                                        <tr><td colSpan="3">No debit entries found.</td></tr>
                                                                    )}
                                                                </tbody>
                                                            </table>
                                                            <button type="button" className="close-btn" onClick={() => setExpandedName(expandedName === task ? null : task)}>Close</button>
                                                        </div></div>}
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="3">No debit entries found.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        )}
                        <h3 onClick={() => setIsDebitNameOpen(!isDebitNameOpen)} className="collapsible-header">
                            📉 Debits - Name Wise {isDebitNameOpen ? "🔽" : "▶️"}
                        </h3>
                        {isDebitNameOpen && (
                            <table className="styled-table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Total Amount Spent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Object.keys(debitsNameWise).length > 0 ? (
                                        Object.keys(debitsNameWise).map(name => (
                                            <tr key={name}>
                                                <td style={{ textAlign: "center" }} onClick={() => setExpandedName(expandedName === name ? null : name)}>
                                                    {expandedName === name ? "▶️" : "🔽"}
                                                </td>
                                                <td>{name}</td>
                                                <td>₹{debitsNameWise[name] ?.totalAmount || 0}</td>
                                                {expandedName === name &&
                                                    <div className="popup-overlay">
                                                        <div className="popup-content">
                                                            <table >
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Task</th>
                                                                        <th>Date</th>
                                                                        <th>Amount</th>
                                                                        <th>Notes</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {debitsNameWise[name].details.length > 0 ? (
                                                                        (debitsNameWise[name].details.map((entry, index) => (
                                                                            <tr key={entry._id}>
                                                                                <td>{entry.name}</td>
                                                                                <td>{entry.task}</td>
                                                                                <td>{entry.date}</td>
                                                                                <td>₹{entry.amount}</td>
                                                                                <td>{entry.notes}</td>
                                                                            </tr>
                                                                        ))
                                                                        )) : (
                                                                        <tr><td colSpan="3">No debit entries found.</td></tr>
                                                                    )}
                                                                </tbody>
                                                            </table>
                                                            <button type="button" className="close-btn" onClick={() => setExpandedName(expandedName === name ? null : name)}>Close</button>
                                                        </div></div>}
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="3">No debit entries found.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        )}
                    </div>


                </div>
                {
                    showPopup && (
                        <div className="popup-overlay">
                            <div className="popup-content">
                                <h3>Add Treasury Entry</h3>
                                <form onSubmit={addTreasuryEntry}>
                                    <label>Select Name : </label>
                                    <select className="dropdown" name="name" onChange={handleTreasuryChange} >
                                        <option value=""></option>
                                        {users.map((user) => (
                                            <option value={user.value}>
                                                {user.label}
                                            </option>
                                        ))}
                                    </select>
                                    <label>Select Task : </label>
                                    <select className="dropdown" name="task" onChange={handleTreasuryChange}>
                                        <option value=""></option>
                                        {tasks.map((task) => (
                                            <option value={task.problemDescription}>
                                                {task.problemDescription}
                                            </option>
                                        ))}
                                    </select>
                                    <label>Select Entry Type: </label>
                                    <select name="type" onChange={handleTreasuryChange}>
                                        <option value=""></option>
                                        <option value="Debit">Debit</option>
                                        <option value="Credit">Credit</option>
                                    </select>
                                    <input type="date" name="date" placeholder="Date" required onChange={handleTreasuryChange} />
                                    <input type="number" name="amount" placeholder="Amount" required onChange={handleTreasuryChange} />
                                    <textarea
                                        name="notes"
                                        value={treasuryForm.notes}
                                        onChange={handleTreasuryChange}
                                        rows="3"
                                        cols="50"
                                        placeholder="Enter Notes..."
                                    />
                                    {/* <input type="text" name="notes" placeholder="Notes" required onChange={handleTreasuryChange} /> */}
                                    <button type="submit" >Submit</button>
                                    <button type="button" className="close-btn" onClick={() => setShowPopup(false)}>Close</button>
                                </form>
                            </div>
                        </div>
                    )
                }

            </div >
        </div >
    );
};

export default Treasury;