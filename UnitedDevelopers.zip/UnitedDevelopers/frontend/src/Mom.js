import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./App.css";
import { ADMIN_USER, ADMIN_PASSWORD, BASE_URI, checkRole, userExist, isUserAdmin } from "./util";

const Mom = () => {
    const [activeTab, setActiveTab] = useState("mom");
    const [momText, setMomText] = useState("");
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    // Fetch Data
    useEffect(() => {
        checkRole();
        if (!userExist)
            navigate("/login");
        else {
            axios.get(BASE_URI + "/mom")
                .then((response) => {
                    if (response.data && response.data.text) {
                        setMomText(response.data.text);
                    }
                    setIsLoading(false);
                })
                .catch((err) => {
                    console.error("Error fetching MOM:", err);
                    setIsLoading(false);
                });
        }
    }, [navigate]);

    const addMom = async (e) => {
        const mobileNumber = localStorage.getItem("mobile");
        axios.post(BASE_URI + "/mom", { mobile: mobileNumber, text: momText }, {
            auth: {
                username: ADMIN_USER,
                password: ADMIN_PASSWORD,
            }
        })
            .then((response) => {
                alert(response.data.message);
            })
            .catch((err) => {
                console.error("Error saving MOM:", err);
            });
    };

    // Handle MOM textarea change
    const handleMomChange = (e) => {
        setMomText(e.target.value);
    };

    const launchActiveTab = (tab) => {
        setActiveTab(tab);
        navigate("/" + tab);
    }

    return (
        <div className="App">
            <div className="sidebar">
                <div >
                    {["dashboard", "treasury", "mom"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </div>
                {/* {isUserAdmin && <span>
                    {["task"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </span>} */}
            </div>

            <div className="content">
                <div className="section">
                    <h2>Minutes of Meeting (MOM)</h2>
                    {isLoading ? (
                        <p>Loading...</p>
                    ) : (
                        <div>
                            <textarea
                                value={momText}
                                onChange={handleMomChange}
                                rows="35"
                                cols="140"
                                placeholder="Enter MOM here..."
                            />
                            <br />
                        </div>
                    )}
                    {isUserAdmin && <button onClick={addMom}>Save MOM</button>}
                </div>
            </div>
        </div>
    );
};

export default Mom;