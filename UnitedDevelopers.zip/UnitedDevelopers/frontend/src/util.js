import axios from "axios";

// Constants
export const BASE_URI = "https://uniteddevelopersapi.netlify.app/.netlify/functions/app";
// export const BASE_URI = "http://localhost:5000";

export const USER_USER = "user";
export const USER_PASSWORD = "password";

export const ADMIN_USER = "admin";
export const ADMIN_PASSWORD = "secret";

export let userExist = false;

export const setUserExist = (newValue) => {
    userExist = newValue;
};

export let isUserAdmin = false;

export const setIsUserAdmin = (newValue) => {
    isUserAdmin = newValue;
};

export async function checkRole() {
    try {
        const id = localStorage.getItem("id");
        const response = await axios.get(BASE_URI + "/user/role/check?_id=" + id);
        userExist = response.data.exists;
        isUserAdmin = response.data.isAdmin;
    } catch (error) {
        console.error(error);
    }
};

export async function checkLoginExpiry() {
    const loginTime = localStorage.getItem("loginTime");
    if (!loginTime) {
        console.log("Timestamp not stored")
        return false;
    }

    const currentTime = Date.now();
    const oneDayInMs = 5 * 60 * 1000; // 1 day in milliseconds
    const timediff = currentTime - loginTime;
    const expired = timediff > oneDayInMs;
    return expired;
};