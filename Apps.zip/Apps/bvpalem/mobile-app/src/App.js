import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Auth from "./Auth";
import Dashboard from "./Dashboard";
import Task from "./Task";
import Mom from "./Mom";
import Treasury from "./Treasury";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Auth />} />
        <Route path="/login" element={<Auth />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/task" element={<Task />} />
        <Route path="/mom" element={<Mom />} />
        <Route path="/treasury" element={<Treasury />} />
      </Routes>
    </Router>
  );
};

export default App;
