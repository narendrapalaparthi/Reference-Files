package vault.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;

import org.apache.commons.codec.binary.Base64;

import com.oracle.bmc.ConfigFileReader;
import com.oracle.bmc.auth.AuthenticationDetailsProvider;
import com.oracle.bmc.auth.SimpleAuthenticationDetailsProvider;
import com.oracle.bmc.auth.SimplePrivateKeySupplier;
import com.oracle.bmc.secrets.SecretsClient;
import com.oracle.bmc.secrets.model.Base64SecretBundleContentDetails;
import com.oracle.bmc.secrets.requests.GetSecretBundleRequest;
import com.oracle.bmc.secrets.responses.GetSecretBundleResponse;
import com.oracle.bmc.vault.VaultsClient;
import com.oracle.bmc.vault.model.Base64SecretContentDetails;
import com.oracle.bmc.vault.model.SecretSummary;
import com.oracle.bmc.vault.model.UpdateSecretDetails;
import com.oracle.bmc.vault.requests.ListSecretsRequest;
import com.oracle.bmc.vault.requests.UpdateSecretRequest;
import com.oracle.bmc.vault.responses.ListSecretsResponse;
import com.oracle.bmc.vault.responses.UpdateSecretResponse;

public class VaultGui {

	private String compartmentId = "ocid1.compartment.oc1..aaaaaaaayakiv6regos3a3cnneam66w7vryebw3myh2r6xxg3jwguhhcph7q";
	private VaultsClient vaultClient;
	private SecretsClient secretClient;

	private static TreeMap<String, String> nameIdmap = new TreeMap<String, String>();
	private static TreeMap<String, String> nameDescriptionmap = new TreeMap<String, String>();

	private JFrame frame;
	private JComboBox<String> actionCombo;
	private SearchableDropdown secretKeyDropdown;
	private JLabel descriptionField;
	private JPasswordField newValueField;
	private JButton executeButton;
	private JButton resetButton;
	private JTextArea outputArea;
	private JProgressBar progressBar;
	private JButton copyButton;
	private JButton clearButton;

	public VaultGui() {
		ConfigFileReader.ConfigFile configWithProfile = null;
		try {
			configWithProfile = ConfigFileReader.parse("~/.oci/config", "service_vault");
		} catch (IOException e) {
			e.printStackTrace();
		}
		Supplier<InputStream> privateKeySupplierFromConfigEntry = new SimplePrivateKeySupplier(
				configWithProfile.get("key_file"));
		AuthenticationDetailsProvider provider = SimpleAuthenticationDetailsProvider.builder()
				.tenantId(configWithProfile.get("tenancy")).userId(configWithProfile.get("user"))
				.fingerprint(configWithProfile.get("fingerprint")).privateKeySupplier(privateKeySupplierFromConfigEntry)
				.build();

		this.vaultClient = VaultsClient.builder().endpoint("https://vaults.us-ashburn-1.oci.oraclecloud.com")
				.build(provider);
		this.secretClient = SecretsClient.builder().endpoint("https://secrets.vaults.us-ashburn-1.oci.oraclecloud.com")
				.build(provider);
	}

	public void updateVaultSecretMaps() {
		String nextPageToken = null;
		do {
			ListSecretsRequest.Builder listSecretsRequest = ListSecretsRequest.builder().compartmentId(compartmentId);

			if (nextPageToken != null) {
				listSecretsRequest.page(nextPageToken);
			}

			/* Send request to the Client */
			ListSecretsResponse response = this.vaultClient.listSecrets(listSecretsRequest.build());

			List<SecretSummary> secrets = response.getItems();

			for (SecretSummary secret : secrets) {
				nameIdmap.put(secret.getSecretName().toLowerCase(), secret.getId());
				nameDescriptionmap.put(secret.getSecretName().toLowerCase(),
						null == secret.getDescription() ? "Discription not found" : secret.getDescription());
			}
			nextPageToken = response.getOpcNextPage();
		} while (nextPageToken != null);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new VaultGui().createAndShowGUI());
	}

	private void createAndShowGUI() {
		updateVaultSecretMaps();
		frame = new JFrame("OCI Vault — Secret Fetch / Update");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(760, 480);
		frame.setMinimumSize(new Dimension(700, 550));
		frame.setLocationRelativeTo(null);

		JPanel root = new JPanel(new BorderLayout(12, 12));
		root.setBorder(new EmptyBorder(14, 14, 14, 14));
		root.setBackground(new Color(0xF3F6F8));

		// Title
		JLabel title = new JLabel("OCI Vault Secret Manager");
		title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
		title.setForeground(new Color(0x0B6FA3));
		root.add(title, BorderLayout.NORTH);

		// Center: form card + output panel
		JPanel center = new JPanel(new GridBagLayout());
		center.setOpaque(false);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(8, 8, 8, 8);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1.0;

		// Card-like panel
		JPanel card = new JPanel(new GridBagLayout());
		card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0xD6EAF2), 1),
				new EmptyBorder(12, 12, 12, 12)));
		card.setBackground(Color.WHITE);

		GridBagConstraints c2 = new GridBagConstraints();
		c2.insets = new Insets(8, 8, 8, 8);
		c2.fill = GridBagConstraints.HORIZONTAL;
		c2.gridx = 0;
		c2.gridy = 0;
		c2.weightx = 0.0;
		JLabel actionLabel = new JLabel("Action:");
		card.add(actionLabel, c2);

		c2.gridx = 1;
		c2.gridy = 0;
		c2.weightx = 1.0;
		actionCombo = new JComboBox<>(new String[] { "Fetch", "Update" });
		actionCombo.setPreferredSize(new Dimension(200, 28));
		card.add(actionCombo, c2);

		c2.gridx = 0;
		c2.gridy = 1;
		c2.weightx = 0.0;
		JLabel keyLabel = new JLabel("Select Vault Secret:");
		card.add(keyLabel, c2);

		c2.gridx = 1;
		c2.gridy = 1;
		c2.weightx = 1.0;
		List<String> keys = new ArrayList<>(nameIdmap.keySet());
		secretKeyDropdown = new SearchableDropdown(keys);
		card.add(secretKeyDropdown, c2);

		c2.gridx = 0;
		c2.gridy = 2;
		c2.weightx = 0.0;
		JLabel descriptionLabel = new JLabel("Description:");
		card.add(descriptionLabel, c2);

		c2.gridx = 1;
		c2.gridy = 2;
		c2.weightx = 1.0;
		descriptionField = new JLabel();
		card.add(descriptionField, c2);

		// Set default description
		updateDescription();

		c2.gridx = 0;
		c2.gridy = 3;
		c2.weightx = 0.0;
		JLabel newValLabel = new JLabel("New Value:");
		card.add(newValLabel, c2);

		c2.gridx = 1;
		c2.gridy = 3;
		c2.weightx = 1.0;
		newValueField = new JPasswordField(); // hide sensitive characters
		newValueField.setEnabled(false);
		card.add(newValueField, c2);

		// Buttons row
		c2.gridx = 0;
		c2.gridy = 4;
		c2.gridwidth = 2;
		c2.fill = GridBagConstraints.NONE;
		c2.anchor = GridBagConstraints.CENTER;
		JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
		btnRow.setOpaque(false);
		executeButton = new JButton("Execute");
		executeButton.setForeground(Color.BLACK);
		executeButton.setFocusPainted(false);
		executeButton.setFont(executeButton.getFont().deriveFont(Font.BOLD, 13f));

		resetButton = new JButton("Reset");
		resetButton.setForeground(Color.BLACK);
		resetButton.setFocusPainted(false);
		resetButton.setFont(resetButton.getFont().deriveFont(Font.BOLD, 13f));

		progressBar = new JProgressBar();
		progressBar.setVisible(false);
		progressBar.setIndeterminate(true);
		progressBar.setPreferredSize(new Dimension(160, 18));

		btnRow.add(executeButton);
		btnRow.add(resetButton);
		btnRow.add(progressBar);

		card.add(btnRow, c2);

		// Add card to center
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1.0;
		gbc.weighty = 0.0;
		center.add(card, gbc);

		// Output panel
		JPanel outputCard = new JPanel(new BorderLayout(8, 8));
		outputCard.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0xD6EAF2), 1),
				new EmptyBorder(10, 10, 10, 10)));
		outputCard.setBackground(Color.WHITE);
		JLabel outputLabel = new JLabel("Response / Secret Value:");
		outputLabel.setFont(outputLabel.getFont().deriveFont(Font.BOLD, 13f));
		outputCard.add(outputLabel, BorderLayout.NORTH);

		outputArea = new JTextArea();
		outputArea.setLineWrap(true);
		outputArea.setWrapStyleWord(true);
		outputArea.setEditable(false);
		outputArea.setFont(outputArea.getFont().deriveFont(13f));
		outputArea.setBackground(new Color(0xFCFEFF));
		JScrollPane sp = new JScrollPane(outputArea);
		sp.setPreferredSize(new Dimension(100, 180));

		outputCard.add(sp, BorderLayout.CENTER);

		JPanel outputBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
		outputBtns.setOpaque(false);
		copyButton = new JButton("Copy");
		clearButton = new JButton("Clear");
		outputBtns.add(clearButton);
		outputBtns.add(copyButton);
		outputCard.add(outputBtns, BorderLayout.SOUTH);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.fill = GridBagConstraints.BOTH;
		center.add(outputCard, gbc);

		root.add(center, BorderLayout.CENTER);

		// Footer with tip + Confluence reference link
		JPanel footerPanel = new JPanel(new BorderLayout());
		footerPanel.setOpaque(false);

		JLabel footerTip = new JLabel("Tip: Ensure OCI config is set.");
		footerTip.setFont(footerTip.getFont().deriveFont(11f));
		footerTip.setForeground(new Color(0x555555));
		footerPanel.add(footerTip, BorderLayout.NORTH);

//		JLabel refLink = new JLabel("<html><a href='https://confluence.oraclecorp.com/confluence/pages/viewpage.action?spaceKey=OMCAP&title=Eloqua+CX+Apps+-+Automation+Jobs+Details#EloquaCXAppsAutomationJobsDetails-VaultUpgrade-SensitiveDataDetails'>Reference: Vault Secret keys Naming Details (Confluence)</a></html>");
//		refLink.setFont(refLink.getFont().deriveFont(11f));
//		refLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//		refLink.setForeground(new Color(0x0B6FA3));
//
//		// Make link clickable in desktop environment
//		refLink.addMouseListener(new java.awt.event.MouseAdapter() {
//		    @Override
//		    public void mouseClicked(java.awt.event.MouseEvent e) {
//		        try {
//		            Desktop.getDesktop().browse(new java.net.URI("https://confluence.oraclecorp.com/confluence/pages/viewpage.action?spaceKey=OMCAP&title=Eloqua+CX+Apps+-+Automation+Jobs+Details#EloquaCXAppsAutomationJobsDetails-VaultUpgrade-SensitiveDataDetails"));
//		        } catch (Exception ex) {
//		            JOptionPane.showMessageDialog(frame, "Failed to open link: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//		        }
//		    }
//		});
//		footerPanel.add(refLink, BorderLayout.SOUTH);

		root.add(footerPanel, BorderLayout.SOUTH);

		secretKeyDropdown.addActionListener(e -> {
			String selected = secretKeyDropdown.getSelectedValue(); // text or selected suggestion
		    descriptionField.setText(nameDescriptionmap.getOrDefault(selected, ""));
		    // hide popup is usually already called by the control, but you can force it:
		    secretKeyDropdown.hidePopup(selected);
		});
		
		// Events & behavior
		actionCombo.addActionListener(this::onActionChange);
		executeButton.addActionListener(this::onExecute);
		resetButton.addActionListener(e -> {
			try {
				createAndShowGUI();
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "Failed to reset form: " + ex.getMessage(), "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		});
		copyButton.addActionListener(e -> copyOutputToClipboard());
		clearButton.addActionListener(e -> outputArea.setText(""));

		// initial UI state
		updateNewValueState();

		frame.setContentPane(root);
		frame.setVisible(true);
	}

	private void onActionChange(ActionEvent ev) {
		updateNewValueState();
	}

	private void updateDescription() {
		String selectedKey = (String) secretKeyDropdown.getSelectedValue();
		if (selectedKey != null && nameDescriptionmap.containsKey(selectedKey)) {
			descriptionField.setText(nameDescriptionmap.get(selectedKey));
		} else {
			descriptionField.setText("");
		}
	}

	private void updateNewValueState() {
		String sel = (String) actionCombo.getSelectedItem();
		boolean update = "Update".equalsIgnoreCase(sel);
		newValueField.setEnabled(update);
		// visually indicate
		newValueField.setBackground(update ? Color.WHITE : new Color(0xF0F0F0));
	}

	private void onExecute(ActionEvent ev) {
		String action = (String) actionCombo.getSelectedItem();
		String secretKey = ((String) secretKeyDropdown.getSelectedValue()).trim();
		char[] newValChars = newValueField.getPassword();
		String newVal = newValChars != null ? new String(newValChars) : "";

		if (secretKey.isEmpty()) {
			JOptionPane.showMessageDialog(frame, "Vault Secret Key / OCID is required.", "Missing input",
					JOptionPane.WARNING_MESSAGE);
			secretKeyDropdown.requestFocus();
			return;
		}
		if ("Update".equalsIgnoreCase(action) && newVal.isEmpty()) {
			JOptionPane.showMessageDialog(frame, "Please provide a new value when Update is selected.", "Missing input",
					JOptionPane.WARNING_MESSAGE);
			newValueField.requestFocus();
			return;
		}

		// run background worker
		executeButton.setEnabled(false);
		progressBar.setVisible(true);
		outputArea.setText("");

		SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {
			@Override
			protected String doInBackground() throws Exception {
				if ("Fetch".equalsIgnoreCase(action)) {
					return fetchSecret(secretKey);
				} else {
					return updateSecret(secretKey, newVal);
				}
			}

			@Override
			protected void done() {
				try {
					String result = get();
					outputArea.setText(result);
				} catch (ExecutionException ex) {
					Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
					outputArea.setText("Error: " + cause.getMessage());
					JOptionPane.showMessageDialog(frame, cause.getMessage(), "Operation Failed",
							JOptionPane.ERROR_MESSAGE);
				} catch (InterruptedException ie) {
					outputArea.setText("Operation interrupted.");
				} finally {
					executeButton.setEnabled(true);
					progressBar.setVisible(false);
				}
			}
		};
		worker.execute();
	}

	private void copyOutputToClipboard() {
		String text = outputArea.getText();
		if (text == null || text.isEmpty()) {
			return;
		}
		StringSelection selection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(selection, null);
		JOptionPane.showMessageDialog(frame, "Copied to clipboard.", "Copied", JOptionPane.INFORMATION_MESSAGE);
	}

	// Fetch secret from OCI Vault
	private String fetchSecret(String secretKey) throws Exception {
		GetSecretBundleRequest getSecretBundleRequest = GetSecretBundleRequest.builder()
				.secretId(getSecretId(secretKey)).build();

		GetSecretBundleResponse response = this.secretClient.getSecretBundle(getSecretBundleRequest);

		Base64SecretBundleContentDetails secretBundleContent = (Base64SecretBundleContentDetails) response
				.getSecretBundle().getSecretBundleContent();

		String encodedValue = secretBundleContent.getContent();
		String decodedValue = encodedValue;
		if (Base64.isBase64(encodedValue))
			decodedValue = new String(Base64.decodeBase64(encodedValue)).toString();

		return decodedValue;
	}

	private String getSecretId(String secretName) {
		return nameIdmap.get(secretName);
	}

	// Update secret in OCI Vault (simplified)
	private String updateSecret(String secretKey, String newValue) {
		newValue = Base64.encodeBase64String(newValue.getBytes(StandardCharsets.UTF_8));

		UpdateSecretDetails updateSecretDetails = UpdateSecretDetails.builder()
				.secretContent(Base64SecretContentDetails.builder().content(newValue).build())
				.enableAutoGeneration(false).build();

		UpdateSecretRequest updateSecretRequest = UpdateSecretRequest.builder().secretId(getSecretId(secretKey))
				.updateSecretDetails(updateSecretDetails).build();

		UpdateSecretResponse response = this.vaultClient.updateSecret(updateSecretRequest);
		if (200 == response.get__httpStatusCode__())
			return "Secret [" + secretKey + "] updated with value: " + newValue;
		else
			return "Secret [" + secretKey + "] updated with value: " + newValue + "was unsuccessful";
	}
}
