package ubi.jmeter;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.ObjectMapper;

public class appupload {
	
	public static void main(String[] args) {
		String excelFilePath = "/Users/npalapar/Downloads/app_login.xlsx";   // ✅ path to your Excel file
        String jsonFilePath = "output.json";  // ✅ output JSON file

        try (FileInputStream fis = new FileInputStream(excelFilePath);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

            XSSFSheet sheet = workbook.getSheet("Sheet18"); // read first sheet
            int rowcount = sheet.getPhysicalNumberOfRows();

            List<String> headers = new ArrayList<>();
            List<Map<String, Object>> jsonData = new ArrayList<>();

            XSSFRow headerRow = sheet.getRow(0);
            int cellCount = headerRow.getPhysicalNumberOfCells();
            for (int i=0; i<cellCount; i++) {
                headers.add(headerRow.getCell(i).getStringCellValue().trim());
            }

            // ✅ Remaining rows = data
            for (int j=1; j<rowcount; j++) {
                XSSFRow row = sheet.getRow(j);
                Map<String, Object> obj = new LinkedHashMap<>();

                for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
                    XSSFCell cell = row.getCell(i);
                    Object value = cell.getRichStringCellValue();

//                    switch (cell.getCellType()) {
//                        case STRING:
//                            value = cell.getStringCellValue();
//                            break;
//                        case NUMERIC:
//                            value = DateUtil.isCellDateFormatted(cell)
//                                    ? cell.getDateCellValue().toString()
//                                    : cell.getNumericCellValue();
//                            break;
//                        case BOOLEAN:
//                            value = cell.getBooleanCellValue();
//                            break;
//                        case FORMULA:
//                            value = cell.getCellFormula();
//                            break;
//                        default:
//                            value = "";
//                    }
                    obj.put(headers.get(i), value);
                }

                jsonData.add(obj);
            }

            // ✅ Write JSON file
            ObjectMapper mapper = new ObjectMapper();
//            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(jsonFilePath), jsonData);
            
            System.out.println("✅ Excel converted to JSON successfully!");
            System.out.println("Output file: " + jsonFilePath);
            System.out.println(jsonData.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
