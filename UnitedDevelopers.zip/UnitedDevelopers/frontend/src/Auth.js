import React, { useState } from "react";
import { FaUser, FaEnvelope, FaKey, FaEye, FaEyeSlash } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./App.css";
import { USER_USER, USER_PASSWORD, BASE_URI, setUserExist } from "./util";

const Auth = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [name, setFullName] = useState("");
  const [message, setMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const role = "user";

  const handleLogin = async () => {
    try {
      const response = await axios.post(BASE_URI + "/login", { password, email }, {
        auth: {
          username: USER_USER,
          password: USER_PASSWORD,
        }
      });
      setMessage(response.data.message);
      localStorage.setItem("id", response.data.id);
      localStorage.setItem("email", response.data.email);
      localStorage.setItem("loginTime", Date.now());
      setUserExist(true);
      navigate("/dashboard");
    } catch (error) {
      console.error(error);
      setMessage(error.response?.data?.message || "Login failed");
    }
  };

  const handleRegister = async () => {
    try {
      const response = await axios.post(BASE_URI + "/register", { password, name, email, role }, {
        auth: {
          username: USER_USER,
          password: USER_PASSWORD,
        }
      });
      setMessage(response.data.message);
      setIsRegister(false);
    } catch (error) {
      setMessage(error.response?.data?.message || "Registration failed");
    }
  };

  const togglePasswordVisibility = () => setShowPassword(!showPassword);

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2>{isRegister ? "Register" : "Login"}</h2>

        {isRegister && (
          <div className="input-group">
            <FaUser className="icon" />
            <input type="text" placeholder="Full Name" value={name} onChange={(e) => setFullName(e.target.value)} />
          </div>
        )}

        <div className="input-group">
          <FaEnvelope className="icon" />
          <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>

        <div className="input-group">
          <FaKey className="icon" />
          <input type={showPassword ? "text" : "password"} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <span onClick={togglePasswordVisibility} >
            {showPassword ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        <button onClick={isRegister ? handleRegister : handleLogin}>
          {isRegister ? "Register" : "Login"}
        </button>

        <p className="message">{message}</p>

        {/* <p className="toggle-link" onClick={() => setIsRegister(!isRegister)}>
          {isRegister ? "Already have an account? Login" : "Don't have an account? Register"}
        </p> */}
      </div>
    </div>
  );
};

export default Auth;