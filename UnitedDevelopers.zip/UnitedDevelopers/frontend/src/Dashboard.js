import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./App.css";
import { ADMIN_USER, ADMIN_PASSWORD, BASE_URI, userExist, isUserAdmin, checkRole } from "./util";

const Dashboard = () => {
    const [activeTab, setActiveTab] = useState("dashboard");
    const [debitsAmount, setDebitsAmount] = useState([]);
    const [creditsAmount, setCreditsAmount] = useState([]);
    const [debits, setDebits] = useState([]);
    const [credits, setCredits] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [leads, setLeads] = useState([]);
    const [userCount, setUserCount] = useState(0);
    const navigate = useNavigate();

    const [isCreditOpen, setIsCreditOpen] = useState(true);
    const [expandedName, setExpandedName] = useState(null);
    const [sortedUsers, setSortedUsers] = useState([]);

    const principalAmount = 49250000;

    // Fetch Data
    useEffect(() => {
        checkRole();
        if (!userExist)
            navigate("/login");
        else {
            axios.get(BASE_URI + "/tasks").then((res) => setTasks(res.data));
            axios.get(BASE_URI + "/leads").then((res) => setLeads(res.data));
            axios.get(BASE_URI + "/treasury").then((res) => {
                setDebitsAmount(res.data.debits);
                setCreditsAmount(res.data.credits);
                const debitsData = res.data.debits;
                const creditsData = res.data.credits;
                const debitGroupedData = debitsData.reduce((acc, entry) => {
                    if (!acc[entry.name]) {
                        acc[entry.name] = {
                            totalAmount: 0
                        };
                    }
                    acc[entry.name].totalAmount += entry.amount;
                    return acc;
                }, {});
                const creditGroupedData = creditsData.reduce((acc, entry) => {
                    if (!acc[entry.name]) {
                        acc[entry.name] = {
                            totalAmount: 0
                        };
                    }
                    acc[entry.name].totalAmount += entry.amount;
                    return acc;
                }, {});
                setDebits(debitGroupedData);
                setCredits(creditGroupedData);
                const sortedUsers = Object.keys(creditGroupedData).sort((a, b) => creditGroupedData[b].totalAmount - creditGroupedData[a].totalAmount);
                setSortedUsers(sortedUsers);
            });
            axios.get(BASE_URI + "/users/count")
                .then((response) => {
                    setUserCount(response.data.count);
                })
                .catch((err) => {
                    console.error("Error fetching user count:", err);
                });
        }
    }, [navigate]);

    const calculateTotals = () => {
        let debitSum = debitsAmount.reduce((sum, entry) => sum + Number(entry.amount), 0);
        let creditSum = creditsAmount.reduce((sum, entry) => sum + Number(entry.amount), 0);
        return { debitSum, creditSum, balance: creditSum - debitSum };
    };

    const calculateSFTInterest = () => {
        const today = new Date();

        // Fixed incomes
        const fixedIncomes = [
            { date: "2025-04-04", amount: 6000000 },
            { date: "2025-05-17", amount: 22000000 },
        ];

        // Interest entries from credits notes starting with "Interest Amount"
        const interestEntries = creditsAmount
            .filter(entry => entry.notes?.startsWith("Interest Amount"))
            .map(entry => ({
                date: entry.date,
                amount: entry.amount
            }));

        const allEntries = [...fixedIncomes, ...interestEntries];

        let sft2Interest = 0;
        let sft15Interest = 0;

        allEntries.forEach(entry => {
            const entryDate = new Date(entry.date);
            const diffDays = Math.floor((today - entryDate) / (1000 * 60 * 60 * 24));
            const interest = entry.amount * (diffDays * 2) / 3000;

            // calculate for both multipliers
            sft2Interest += interest * 1;     // multiplied by 2 in display
            sft15Interest += interest * 0.75; // multiplied by 1.5 in display
        });
        let sft2Cost = (sft2Interest+principalAmount)/12875;
        let sft15Cost = (sft15Interest+principalAmount)/12875;
        return { sft2Cost, sft15Cost};
    };

    const launchActiveTab = (tab) => {
        setActiveTab(tab);
        navigate("/" + tab);
    }

    const updateLeadStatus = async (id, newStatus) => {
        try {
            await axios.put(`${BASE_URI}/leads/${id}`, { status: newStatus }, {
                auth: {
                    username: ADMIN_USER,
                    password: ADMIN_PASSWORD,
                }
            });
            setLeads((prevLeads) =>
                prevLeads.map((lead) =>
                    lead._id === id ? { ...lead, status: newStatus } : lead
                )
            );
        } catch (error) {
            console.error("Error updating lead status:", error);
        }
    };

    const { debitSum, creditSum, balance } = calculateTotals();
    const { sft2Cost, sft15Cost } = calculateSFTInterest();

    return (
        <div className="App">
            <div className="sidebar">
                <div >
                    {["dashboard", "treasury", "mom"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </div>
                {/* {isUserAdmin && <span>
                    {["task"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </span>} */}
            </div>
            <div className="content">
                <div className="section">
                    {/* <h2>Dashboard</h2> */}
                    <div className="dashboard-summary">

                        <div className="summary-card">
                            <i className="fas fa-wallet balance-icon"></i>
                            <div className="summary-title">Balance Amount</div>
                            <div className="summary-value">₹{balance}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-up credit-icon"></i>
                            <div className="summary-title">Amount Funded</div>
                            <div className="summary-value">₹{creditSum}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-down debit-icon"></i>
                            <div className="summary-title">Amount Spent</div>
                            <div className="summary-value">₹{debitSum}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-down debit-icon"></i>
                            <div className="summary-value">SFT - ₹2 : ₹{sft2Cost.toFixed(0)}</div>
                            <div className="summary-value">SFT - ₹1.5 : ₹{sft15Cost.toFixed(0)}</div>
                        </div>

                    </div>
                    <h2 class="treasury-title">💰 Individual Accounts</h2>
                    <table className="task-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Total Amount Funded</th>
                                <th>Total Amount Spent</th>
                                <th>Balance Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Object.keys(credits).length > 0 ? (
                                sortedUsers.map(name => (
                                    <tr key={name}>
                                        <td>{name}</td>
                                        <td>₹{credits[name].totalAmount}</td>
                                        <td>₹{debits[name]?.totalAmount || 0}</td>
                                        <td><strong>₹{(credits[name].totalAmount) - (debits[name]?.totalAmount || 0)}</strong></td>
                                    </tr>
                                ))
                            ) : (
                                <tr><td colSpan="3">No credit entries found.</td></tr>
                            )}
                        </tbody>
                    </table>
                    <h2 class="treasury-title">Tasks Status Information</h2>
                    <table className="task-table">
                        <thead>
                            <tr>
                                <th>Task</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <th>Started Date</th>
                                <th>Completed Date</th>
                                <th>Time Duration(In Days)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tasks.map((task, index) => (
                                <tr key={index}>
                                    <td>{task.problemDescription}</td>
                                    <td><span className={`badge status-${task.status.toLowerCase()}`}>
                                        {task.status}
                                    </span></td>
                                    <td> <span className={`badge priority-${task.priority.toLowerCase()}`}>
                                        {task.priority}
                                    </span></td>
                                    <td>{task.createdDate}</td>
                                    <td>{task.updatedDate}</td>
                                    <td>{task.duration}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <h2 className="treasury-title">Leads Information</h2>
                    <table className="task-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Comments</th>
                                <th>Status</th>
                                <th>Submitted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {leads.map((lead, index) => (
                                <tr key={index}>
                                    <td>{lead.name}</td>
                                    <td>{lead.email}</td>
                                    <td>{lead.phone}</td>
                                    <td>{lead.message}</td>
                                    <td>
                                        <select
                                            value={lead.status}
                                            disabled={lead.status === "Closed" || lead.status === "Opportunity"}
                                            onChange={(e) => updateLeadStatus(lead._id, e.target.value)}
                                            className="status-select"
                                        >
                                            <option value="Submitted">Submitted</option>
                                            <option value="Contacted">Contacted</option>
                                            <option value="Opportunity">Opportunity</option>
                                            <option value="Closed">Closed</option>
                                        </select>
                                    </td>
                                    <td>{lead.date?.slice(0, 10)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;