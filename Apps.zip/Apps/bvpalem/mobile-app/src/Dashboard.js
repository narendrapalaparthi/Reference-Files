import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./App.css";
import { BASE_URI, userExist, isUserAdmin, checkRole } from "./util";

const Dashboard = () => {
    const [activeTab, setActiveTab] = useState("dashboard");
    const [debits, setDebits] = useState([]);
    const [credits, setCredits] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [userCount, setUserCount] = useState(0);
    const navigate = useNavigate();

    // Fetch Data
    useEffect(() => {
        checkRole();
        if (!userExist)
            navigate("/login");
        else {
            axios.get(BASE_URI + "/tasks").then((res) => setTasks(res.data));
            axios.get(BASE_URI + "/treasury").then((res) => { setDebits(res.data.debits); setCredits(res.data.credits) });
            axios.get(BASE_URI + "/users/count")
                .then((response) => {
                    setUserCount(response.data.count);
                })
                .catch((err) => {
                    console.error("Error fetching user count:", err);
                });
        }
    }, [navigate]);

    const calculateTotals = () => {
        let debitSum = debits.reduce((sum, entry) => sum + Number(entry.amount), 0);
        let creditSum = credits.reduce((sum, entry) => sum + Number(entry.amount), 0);
        return { debitSum, creditSum, balance: creditSum - debitSum };
    };

    const launchActiveTab = (tab) => {
        setActiveTab(tab);
        navigate("/" + tab);
    }

    const { debitSum, creditSum, balance } = calculateTotals();

    return (
        <div className="App">
            <div className="sidebar">
                <div >
                    {["dashboard", "treasury", "mom"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </div>
                {isUserAdmin && <span>
                    {["task"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </span>}
            </div>
            <div className="content">
                <div className="section">
                    {/* <h2>Dashboard</h2> */}
                    <div className="dashboard-summary">

                        <div className="summary-card">
                            <i className="fas fa-wallet balance-icon"></i>
                            <div className="summary-title">Balance Amount</div>
                            <div className="summary-value">₹{balance}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-up credit-icon"></i>
                            <div className="summary-title">Amount Funded</div>
                            <div className="summary-value">₹{creditSum}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-down debit-icon"></i>
                            <div className="summary-title">Amount Spent</div>
                            <div className="summary-value">₹{debitSum}</div>
                        </div>
                        <div className="summary-card">
                            <i className="fas fa-arrow-down debit-icon"></i>
                            <div className="summary-title">Registered Users</div>
                            <div className="summary-value">{userCount}</div>
                        </div>

                    </div>
                    <table className="task-table">
                        <thead>
                            <tr>
                                <th>Problem</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <th>Owners</th>
                                <th>Temporary Solution</th>
                                <th>Permanent Solution</th>
                                <th>Created Date</th>
                                <th>Last Updated Date</th>
                                <th>Comments</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tasks.map((task, index) => (
                                <tr key={index}>
                                    <td>{task.problemDescription}</td>
                                    <td><span className={`badge status-${task.status.toLowerCase()}`}>
                                        {task.status}
                                    </span></td>
                                    <td> <span className={`badge priority-${task.priority.toLowerCase()}`}>
                                        {task.priority}
                                    </span></td>
                                    <td>{task.owners}</td>
                                    <td>{task.temporarySolution}</td>
                                    <td>{task.permanentSolution}</td>
                                    <td>{task.createdDate}</td>
                                    <td>{task.updatedDate}</td>
                                    <td>{task.comments}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;