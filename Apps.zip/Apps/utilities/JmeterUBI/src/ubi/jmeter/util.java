package ubi.jmeter;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Scanner;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class util {

	public static final String ENDPOINT = "https://dc.b.dev.infinitycloud.io/v3/responsys_ubi_integration"; // ?dcsverbose=true

	public static final String EMAIL = "ubi_test_email%d_%d@email.com";

	public static final int NUMBER_OF_EVENTS = 1;

	public static boolean isUserInStaticBlock = false;
	public static boolean isMetadataInStaticBlock = false;
	
	public static int maxCharactersLength = 100;
	
	public static String FixedText = "-length"+maxCharactersLength+"-";

	public static void main(String[] args) throws JSONException, MalformedURLException, IOException {
		String payload = getPayload(NUMBER_OF_EVENTS, isUserInStaticBlock, isMetadataInStaticBlock, 1);
		getResponse(payload);
	}
	
	public static String getPayload(int eventsCount, boolean userInStaticBlock, boolean metadataInStaticBlock, int threadcount) {
		String correlationId = UUID.randomUUID().toString();
		String randomText = "";
		if(maxCharactersLength-7 > 0)
			randomText = FixedText + RandomStringUtils.random(maxCharactersLength-6-FixedText.length(), true, false);

		JSONObject mainJson = new JSONObject();
		JSONObject staticJson = new JSONObject();
		JSONArray eventsJson = new JSONArray();

		staticJson.put("es", "responsys");

		if (userInStaticBlock) {
			JSONObject user = new JSONObject();

			user.put("param1", "value1");
			user.put("param2", "value2");
			user.put("param3", "value3");
			user.put("param4", "value4");
			user.put("param5", "value5");

			staticJson.put("user", user);
		}

		if (metadataInStaticBlock) {
			JSONObject ora = new JSONObject();
			JSONObject matadata = new JSONObject();

			matadata.put("correlationId", correlationId);
			matadata.put("assetId", 1);
			matadata.put("tenantId", 3);
			ora.put("rsys", (new JSONObject()).put("event", matadata));

			staticJson.put("ora", ora);
		}

		for (int i = 1; i <= eventsCount; i++) {
			JSONObject event = new JSONObject();

			if (!userInStaticBlock) {
				JSONObject user = new JSONObject();

				user.put("param1", "value1-"+i);
				user.put("param2", "value2-"+i);
				user.put("param3", "value3-"+i);
				user.put("param4", "value4-"+i);
				user.put("param5", "value5-"+i);

				event.put("user", user);
			}

			if (!metadataInStaticBlock) {
				JSONObject ora = new JSONObject();
				JSONObject matadata = new JSONObject();

				matadata.put("correlationId", correlationId);
				matadata.put("assetId", 1);
				matadata.put("tenantId", 3);
				ora.put("rsys", (new JSONObject()).put("event", matadata));

				event.put("ora", ora);
			}

			JSONObject wt = new JSONObject();

			wt.put("ev", "UBI_PERSONALIZATION");
			wt.put("dcsvid", getSHAEmail(String.format(EMAIL, threadcount, i)));
			wt.put("dl", 300);
			wt.put("ets", Instant.now().getEpochSecond());

			event.put("wt", wt);

			eventsJson.put(event);
		}

		mainJson.put("static", staticJson);
		mainJson.put("events", eventsJson);

//		System.out.println(mainJson.toString());
		
		return mainJson.toString();
	}

	public static String getSHAEmail(String email) {
		try {
			final MessageDigest digest = MessageDigest.getInstance("SHA-256");
			final byte[] hash = digest.digest(email.getBytes("UTF-8"));
			final StringBuilder hexString = new StringBuilder();
			for (int i = 0; i < hash.length; i++) {
				final String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public static void getResponse(String payload) throws MalformedURLException, IOException {
		HttpsURLConnection conn = (HttpsURLConnection) new URL(ENDPOINT).openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Accept", "application/json");
		conn.setRequestProperty("Content-Type", "application/json");

		conn.setDoInput(true);
		conn.setDoOutput(true);

		DataOutputStream wr;
		wr = new DataOutputStream(conn.getOutputStream());
		wr.writeBytes(payload);
		wr.flush();
		wr.close();

		int responseCode = -1;
		String responseMessage = null;
		responseCode = conn.getResponseCode();
		responseMessage = conn.getResponseMessage();
		System.out.println("Response Code : " + responseCode);
		System.out.println("Response Message: " + responseMessage);

		Scanner in;
		String responseBody = "";
		try {
			if (responseCode >= 400 && responseCode <= 510) {
				in = new Scanner(conn.getErrorStream());
			} else {
				in = new Scanner(conn.getInputStream());
			}
			while (in.hasNextLine()) {
				responseBody = responseBody.concat(in.nextLine());
			}
			in.close();
			System.out.println("Response Body : " + responseBody);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
