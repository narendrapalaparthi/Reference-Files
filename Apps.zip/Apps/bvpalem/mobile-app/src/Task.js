import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./App.css";
import { ADMIN_USER, ADMIN_PASSWORD, BASE_URI, checkRole, userExist, isUserAdmin } from "./util";

const Task = () => {
    const [activeTab, setActiveTab] = useState("task");
    const [tasks, setTasks] = useState([]);
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState("");

    const [editing, setEditing] = useState(false);
    const [editId, setEditId] = useState(null);

    // Fetch tasks on load
    useEffect(() => {
        checkRole();
        if (!userExist)
            navigate("/login");
        else {
            fetchTasks();
        }
    }, [navigate]);

    const fetchTasks = async () => {
        try {
            axios.get(BASE_URI + "/tasks").then((res) => setTasks(res.data));
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    }

    const [task, setTask] = useState({
        problemDescription: "",
        status: "",
        priority: "",
        temporarySolution: "",
        permanentSolution: "",
        owners: "",
        comments: "",
        mobile: localStorage.getItem("mobile"),
    });

    // Handle Input Change
    const handleChange = (e) => {
        setTask({ ...task, [e.target.name]: e.target.value });
    };

    // Submit Task (Add or Update)
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editing) {
                const mobile = localStorage.getItem("mobile");
                await axios.put(BASE_URI + `/tasks/${editId}`, { task: task, mobile: mobile }, {
                    auth: {
                        username: ADMIN_USER,
                        password: ADMIN_PASSWORD,
                    }
                }).then((response) => {
                    alert(response.data.message);
                });

            } else {
                await axios.post(BASE_URI + "/tasks", task, {
                    auth: {
                        username: ADMIN_USER,
                        password: ADMIN_PASSWORD,
                    }
                }).then((response) => {
                    alert(response.data.message);
                });
            }
            fetchTasks();
            resetForm();
        } catch (error) {
            console.error("Error saving task:", error);
        }
    };

    // Edit Task
    const handleEdit = (task) => {
        setEditing(true);
        setEditId(task._id);
        setTask(task);
    };

    // Reset Form
    const resetForm = () => {
        setTask({
            problemDescription: "",
            status: "",
            priority: "",
            temporarySolution: "",
            permanentSolution: "",
            owners: "",
            comments: "",
            mobile: localStorage.getItem("mobile"),
        });
        setEditing(false);
        setEditId(null);
    };

    const launchActiveTab = (tab) => {
        setActiveTab(tab);
        navigate("/" + tab);
    }

    return (
        <div className="App">
            <div className="sidebar">
                <div >
                    {["dashboard", "treasury", "mom"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </div>
                {isUserAdmin && <span>
                    {["task"].map((tab) => (
                        <div key={tab} className={`tab ${activeTab === tab ? "active" : ""}`} onClick={() => launchActiveTab(tab)}>
                            {tab.toUpperCase()}
                        </div>
                    ))}
                </span>}
            </div>

            <div className="content">
                <div className="task-container">
                    <h2>{editing ? "Edit Task" : "Add Task"}</h2>
                    <form onSubmit={handleSubmit}>
                        <input type="text" name="problemDescription" placeholder="Task Description" value={task.problemDescription} onChange={handleChange} required />
                        <p>Select Status :
                            <select name="status" onChange={handleChange} required>
                                <option value={task.status}>{task.status}</option>
                                <option value="Open">Open</option>
                                <option value="InProgress">InProgress</option>
                                <option value="Completed">Completed</option>
                            </select> </p>
                        <p>Select Priority :
                            <select name="priority" onChange={handleChange} required>
                                <option value={task.priority}>{task.priority}</option>
                                <option value="High">High</option>
                                <option value="Medium">Medium</option>
                                <option value="Low">Low</option>
                            </select> </p>
                        {/* <input type="text" name="temporarySolution" placeholder="Temporary Solution" value={task.temporarySolution} onChange={handleChange} />
                        <input type="text" name="permanentSolution" placeholder="Permanent Solution" value={task.permanentSolution} onChange={handleChange} /> 
                        <input type="text" name="owners" placeholder="Owners" value={task.owners} onChange={handleChange} />
                        <input type="text" name="comments" placeholder="Comments" value={task.comments} onChange={handleChange} />*/}
                        <textarea
                            name="owners"
                            value={task.owners}
                            onChange={handleChange}
                            rows="3"
                            cols="50"
                            placeholder="Enter Owner Names..."
                        />
                        <textarea
                            name="temporarySolution"
                            value={task.temporarySolution}
                            onChange={handleChange}
                            rows="5"
                            cols="100"
                            placeholder="Enter Temporary Solution..."
                        />
                        <textarea
                            name="permanentSolution"
                            value={task.permanentSolution}
                            onChange={handleChange}
                            rows="5"
                            cols="100"
                            placeholder="Enter Permanent Solution..."
                        />
                        <textarea
                            name="comments"
                            value={task.comments}
                            onChange={handleChange}
                            rows="5"
                            cols="100"
                            placeholder="Enter Comments..."
                        />

                        {/* <input type="date" name="createdDate" placeholder="Created Date" value={task.createdDate} onChange={handleChange} />
                        <input type="date" name="updatedDate" placeholder="Updated Date" value={task.updatedDate} onChange={handleChange} /> */}


                        <button type="submit">{editing ? "Update Task" : "Add Task"}</button>
                        {editing && <button type="button" onClick={resetForm}>Cancel</button>}
                    </form>

                    <h2>Search specific task to update...</h2>
                    {/* Search Input */}
                    <input type="text" placeholder="Search Task..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />

                    {/* Task List Table */}
                    <table>
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tasks && Array.isArray(tasks) && tasks
                                .filter((task) => task.problemDescription.toLowerCase().includes(searchTerm.toLowerCase()))
                                .map((task) => (
                                    <tr key={task._id}>
                                        <td>{task.problemDescription}</td>
                                        <td>
                                            <button onClick={() => handleEdit(task)}>Edit</button>
                                        </td>
                                    </tr>
                                ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Task;