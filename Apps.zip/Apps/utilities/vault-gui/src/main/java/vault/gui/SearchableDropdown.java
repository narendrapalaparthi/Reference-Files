package vault.gui;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/** AutoCompleteField with ActionListener support and hidePopup() */
public class SearchableDropdown extends JPanel {
    private final JTextField textField = new JTextField();
    private final JPopupMenu popup = new JPopupMenu();
    private final JList<String> suggestionList = new JList<>();
    private List<String> data = new ArrayList<>();
    private final java.util.List<ActionListener> actionListeners = new ArrayList<>();

    public SearchableDropdown(List<String> items) {
        super(new BorderLayout());
        this.data = new ArrayList<>(items);

        suggestionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        suggestionList.setFocusable(false);
        suggestionList.setVisibleRowCount(8);

        JScrollPane sc = new JScrollPane(suggestionList);
        sc.setBorder(null);
        popup.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        popup.add(sc);
        popup.setFocusable(false);
        popup.setVisible(true);

        // Document listener -> filter (use invokeLater so document updates are applied)
        textField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { SwingUtilities.invokeLater(() -> filterAndShow()); }
            public void removeUpdate(DocumentEvent e) { SwingUtilities.invokeLater(() -> filterAndShow()); }
            public void changedUpdate(DocumentEvent e) { SwingUtilities.invokeLater(() -> filterAndShow()); }
        });

        // Show all items on focus if empty
        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                SwingUtilities.invokeLater(() -> {
                    if (textField.getText().trim().isEmpty()) showSuggestions(data);
                });
            }
            @Override
            public void focusLost(FocusEvent e) {
                // give mouse click handler chance to run
                SwingUtilities.invokeLater(() -> popup.setVisible(false));
            }
        });

        // Mouse pick
        suggestionList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    String selected = suggestionList.getSelectedValue();
                    if (selected != null) {
                        setSelectedValue(selected);
                        popup.setVisible(false);
                        fireActionEvent(selected);
                    }
                }
            }
        });

        // Enter key: pick currently selected suggestion if any
        textField.addActionListener(e -> {
            String sel = null;
            if (!suggestionList.isSelectionEmpty()) {
                sel = suggestionList.getSelectedValue();
            } else if (!textField.getText().trim().isEmpty()) {
                sel = textField.getText().trim();
            }

            if (sel != null) {
                setSelectedValue(sel);
                fireActionEvent(sel);
            }
            popup.setVisible(false);
        });

        // Down arrow moves selection in list (without stealing focus)
        textField.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "selectNext");
        textField.getActionMap().put("selectNext", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (popup.isVisible()) {
                    int size = suggestionList.getModel().getSize();
                    if (size > 0) {
                        int idx = Math.max(0, suggestionList.getSelectedIndex());
                        idx = Math.min(size - 1, idx + 1);
                        suggestionList.setSelectedIndex(idx);
                        suggestionList.ensureIndexIsVisible(idx);
                    }
                } else {
                    filterAndShow();
                }
            }
        });

        // Up arrow
        textField.getInputMap().put(KeyStroke.getKeyStroke("UP"), "selectPrev");
        textField.getActionMap().put("selectPrev", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (popup.isVisible()) {
                    int size = suggestionList.getModel().getSize();
                    if (size > 0) {
                        int idx = suggestionList.getSelectedIndex();
                        if (idx <= 0) idx = 0; else idx = idx - 1;
                        suggestionList.setSelectedIndex(idx);
                        suggestionList.ensureIndexIsVisible(idx);
                    }
                }
            }
        });

        add(textField, BorderLayout.CENTER);
    }

    private void filterAndShow() {
        String input = textField.getText().toLowerCase().trim();
        List<String> filtered;
        if (input.isEmpty()) {
            filtered = data; // show all when empty
        } else {
            filtered = data.stream()
                    .filter(s -> s.toLowerCase().contains(input))
                    .collect(Collectors.toList());
        }
        showSuggestions(filtered);
    }

    private void showSuggestions(List<String> items) {
        if (items == null || items.isEmpty()) {
            popup.setVisible(false);
            return;
        }
        suggestionList.setListData(items.toArray(new String[0]));
        suggestionList.setSelectedIndex(0);
        try {
            popup.show(textField, 0, textField.getHeight());
        } catch (IllegalComponentStateException ex) {
            // ignore if not yet displayable
        }
    }

    // ---- new API methods ----
    public void addActionListener(ActionListener l) {
        if (l != null) actionListeners.add(l);
    }

    private void fireActionEvent(String selected) {
        ActionEvent evt = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, selected);
        for (ActionListener l : new ArrayList<>(actionListeners)) {
            try { l.actionPerformed(evt); } catch (Exception ignored) {}
        }
    }

    public void hidePopup(String selectedValue) {
    	textField.setText(selectedValue);
		popup.setVisible(false);	
    }

    public void updateItems(List<String> items) {
        this.data = new ArrayList<>(items);
    }

    public void clear() {
        textField.setText("");
        popup.setVisible(false);
    }

    public String getSelectedValue() {
        return textField.getText();
    }

    public void setSelectedValue(String value) {
        textField.setText(value);
    }

    // optional: expose the underlying JTextField if needed
    public JTextField getTextField() {
        return textField;
    }
}